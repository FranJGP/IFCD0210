package pwsj;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

import javax.xml.ws.Endpoint;

@WebService(serviceName = "JavaWebService")
public class JavaWebService {

    @WebMethod(operationName = "saludo")
    public String saludo(@WebParam(name = "nombre") String nombre) {
        //TODO write your implementation code here:
        return "Hola "+nombre+" espero que disfrutes del web service.";
    }


        @WebMethod(operationName = "Sumar")
	public int sumar(int x, int y) {
            int result;
            result = x + y;
		return result;
	}
        @WebMethod(operationName = "Restar")
	public int restar(int x, int y) {
            int result;
            result = x - y;
		return result;
	}
        @WebMethod(operationName = "Multiplicar")
	public int multiplicar(int x, int y) {
            int result;
            result = x * y;
		return result;
	}
        @WebMethod(operationName = "Dividir")
	public int dividir(int x, int y) {
            int result;
            result = x / y;
		return result;
	}
   

    /**
     * Web service operation
     */
    @WebMethod(operationName = "longitud")
    public String longitud(@WebParam(name = "nombre") String nombre) {
        int longitud=nombre.length();
        return "La longitud de tu palabra es " + longitud;
    }
    
    
    
}








