
package pkg;

import static java.lang.System.out;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.Endpoint;


@WebService(serviceName = "funciones")
public class funciones {

	public int compute(int x, int y, String operation) {
		return funciones.calculate(x, y, operation);
	}

	public static int calculate(int x, int y, String operation) {
		int result;
		String op;

		if ("+".equals(operation)) {
			result = x + y;
			op = "+";
		} else if ("-".equals(operation)) {
			result = x - y;
			op = "-";
		} else if ("*".equals(operation)) {
			result = x * y;
			op = "*";
		} else if ("/".equals(operation)) {
			result = x / y;
			op = "/";
		} else if ("^".equals(operation)) {
			result = (int) Math.pow(x,y);
			op = "^";
		} else {
			// defaults to SUB
			result = x - y;
			op = "-";
		}

		log(x, y, result, op);

		return result;
	}

	private static void log(int x, int y, int result, String op) {
		System.out.format("%d %s %d = %d%n", x, op, y, result);
	}
}