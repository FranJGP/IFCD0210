package E2_practica;

import java.awt.EventQueue;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.awt.SystemColor;
import javax.swing.border.CompoundBorder;

public class DesktopAppv2 extends JFrame {

	/**
	 * Este codigo representa lo que he realizado para la practica E2.
	 */
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DesktopAppv2 frame = new DesktopAppv2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public DesktopAppv2() {
		
	//A�ade un titulo, no es estrictamente necesario
        setTitle("DesktopApp");
    /*Indica que cuando se cierre la ventana se acaba la aplicacion,
     si no lo indicamos cuando cerremos la ventana la aplicacion seguira funcionando*/
        setDefaultCloseOperation(EXIT_ON_CLOSE);
	/*Coordenadas x y de la aplicacion y su altura y longitud,
     * si no lo indicamos aparecera una ventana muy peque�a*/
        setBounds(200, 200, 600, 450);
	//Creamos el panel asignando a una variable (contentPane) la funci�n que crea la ventana
		contentPane = new JPanel();
		contentPane.setForeground(SystemColor.textHighlight);
		contentPane.setBorder(new CompoundBorder());
		contentPane.setBackground(SystemColor.activeCaption);
	//Hace visible la ventana, si no lo hacemos no veremos la aplicacion
        setVisible(true);
	//Indicamos su dise�o
		contentPane.setLayout(null);
	//asigno el pannel a la ventana
		setContentPane(contentPane);

		
	//Vamos a crear una etiqueta:	
		JLabel etiqueta=new JLabel("�Bienvenido a la DesktopApp!");
		//asignamos las medidas del campo
		etiqueta.setBounds(40, 21, 200, 20);
		contentPane.add(etiqueta);
	//campo con texto de area
        JTextArea textArea = new JTextArea("Esto es un texto simple en una caja de texto con area. \n \n "
        									+ "Existen diferentes campos con los que puedes interactuar. \n \n "
        									+ "Por ejemplo, un bot�n, o un campo para contrase�as.\n \n "
        									+ "Tambi�n puedes escribir tu nombre en el campo vacio que est� debajo de este. \n \n"
        									+ "O eseleccionar una opci�n... o varias...");
        textArea.setBounds(0, 6, 128, 162);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        contentPane.add(textArea);
        //a�adimos un scroll para poder visualizar el texto entero:
        	JScrollPane scroll = new JScrollPane(textArea); //Objeto
        	scroll.setBounds(40, 52, 200, 139); //Misma coordenadas y tama�o que el objeto
        	contentPane.add(scroll);	
		
    //Texto explicativo para el nombre:
       	JLabel label_1 = new JLabel("�Aqui puedes escribir tu nombre...");
       	label_1.setBounds(40, 217, 200, 20);
       	contentPane.add(label_1);	
	//Campo de texto:
		JTextField textField = new JTextField();
		textField.setBackground(SystemColor.inactiveCaptionBorder);
		textField.setBounds(40, 248, 200, 23);
		contentPane.add(textField);
	
	//Texto explicativo para la contrase�a:
   		JLabel label_2 = new JLabel(" o tu contrase�a ultrasecreta!");
   		label_2.setBounds(40, 284, 200, 20);
   		contentPane.add(label_2);
   	//vamos a agregar un campo para contrase�as
    	JPasswordField pwd = new JPasswordField("");
    	pwd.setBackground(SystemColor.inactiveCaptionBorder);
    	pwd.setBounds(40, 315, 200, 20);
    	contentPane.add(pwd);	

    //vamos a agregar un interruptor
    	JToggleButton tglbtnNewToggleButton = new JToggleButton("Pulsame!! :D", true);
    	tglbtnNewToggleButton.setBackground(SystemColor.info);
    	tglbtnNewToggleButton.setBounds(51, 357, 171, 23);
   		contentPane.add(tglbtnNewToggleButton);	
		
	//Texto explicativo para opciones	
   		JLabel label = new JLabel("Eligir tu equipo... o varios!");
   		label.setBounds(328, 24, 200, 20);
   		contentPane.add(label);
	//Bot�n de radio:
		JRadioButton rdbtnOpcion= new JRadioButton("Bar�a", true);
		rdbtnOpcion.setBackground(SystemColor.inactiveCaption);
        rdbtnOpcion.setBounds(294, 72, 97, 23);
        contentPane.add(rdbtnOpcion);
        JRadioButton rdbtnOpcion_1 = new JRadioButton("Madrid", false);
        rdbtnOpcion_1.setBackground(SystemColor.inactiveCaption);
        rdbtnOpcion_1.setBounds(294, 98, 97, 23);
        contentPane.add(rdbtnOpcion_1);
        JRadioButton rdbtnOpcion_2 = new JRadioButton("Betis", false);
        rdbtnOpcion_2.setBackground(SystemColor.inactiveCaption);
        rdbtnOpcion_2.setBounds(294, 124, 97, 23);
        contentPane.add(rdbtnOpcion_2);
        ButtonGroup bgroup = new ButtonGroup();
        bgroup.add(rdbtnOpcion);
        bgroup.add(rdbtnOpcion_1);
        bgroup.add(rdbtnOpcion_2);

	//Bot�n con checkbox
        JCheckBox chckbxOpcion = new JCheckBox("Bar�a", true);
        chckbxOpcion.setBackground(SystemColor.inactiveCaption);
        chckbxOpcion.setBounds(441, 72, 97, 23);
        contentPane.add(chckbxOpcion);
        JCheckBox chckbxNewCheckBox = new JCheckBox("Madrid", true);
        chckbxNewCheckBox.setBackground(SystemColor.inactiveCaption);
        chckbxNewCheckBox.setBounds(441, 98, 97, 23);
        contentPane.add(chckbxNewCheckBox);
        JCheckBox chckbxOpcion_1 = new JCheckBox("Betis", false);
        chckbxOpcion_1.setBackground(SystemColor.inactiveCaption);
        chckbxOpcion_1.setBounds(441, 124, 97, 23);
        contentPane.add(chckbxOpcion_1);
       			
    //texto explicativo para campo de seleccion y spinner
       		JLabel label_3 = new JLabel("Elegir tu heroe favorito...  o tu edad!");
       		label_3.setBounds(294, 176, 234, 20);
       		contentPane.add(label_3);
    //campo de seleccion
        	JComboBox<Object> comboBox = new JComboBox<>();
        	comboBox.setBackground(SystemColor.inactiveCaption);
        	comboBox.setBounds(294, 216, 141, 22);
        	contentPane.add(comboBox);
        		comboBox.addItem("SuperMan");
        		comboBox.addItem("Batman");
        		comboBox.addItem("Aquaman");
        		comboBox.addItem("Ironman");
        		comboBox.addItem("El capi");
        		comboBox.addItem("Hulk");
    //agregamos un JSpinner
       		JSpinner spinner = new JSpinner();
       		spinner.setBackground(SystemColor.inactiveCaptionBorder);
       		spinner.setBounds(481, 217, 57, 20);
       		contentPane.add(spinner);
       		
    //texto explicativo para las listas	
       		JLabel label_4 = new JLabel("Y aqu�... una lista de pelis!");
       		label_4.setBounds(294, 249, 200, 20);
       		contentPane.add(label_4);	
	//Arrays de String
      		String pelis[]={"Star wars: la venganza de los siths", "El se�or de los anillos: el retorno del rey", "Guerra mundial Z", "Revolution", "007: Todo o Nada"};
       		JList list = new JList<>(pelis);
       		list.setBounds(294, 284, 250, 100);
       		contentPane.add(list);	
       	
	}
}
