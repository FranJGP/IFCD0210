package E2_ejemplo;

import java.awt.EventQueue;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

public class DesktopAppv1 extends JFrame {

	/**
	 * Este codigo est� sacado de Disco Duro de Roer, a modo de ejemplo para poder realizar la 
	 * practica del segundo modulo E2.
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DesktopAppv1 frame = new DesktopAppv1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		//Seg�n el ejemplo deber�a ser lo siguiente, pero lo anterior es mas completo
		//DesktopAppv1 ventana=new DesktopAppv1();
	}

	/**
	 * Create the frame.
	 */
	public DesktopAppv1() {
	//A�ade un titulo, no es estrictamente necesario
        setTitle("DesktopApp");
        
    /*Indica que cuando se cierre la ventana se acaba la aplicacion,
     si no lo indicamos cuando cerremos la ventana la aplicacion seguira funcionando*/
        setDefaultCloseOperation(EXIT_ON_CLOSE);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	/*Coordenadas x y de la aplicacion y su altura y longitud,
     * si no lo indicamos aparecera una ventana muy peque�a*/
        setBounds(400, 200, 607, 448);
		//setBounds(100, 100, 450, 300);
		
	//Creamos el panel asignando a una variable (contentPane) la funci�n que crea la ventana
		contentPane = new JPanel();
		
	//Hace visible la ventana, si no lo hacemos no veremos la aplicacion
        setVisible(true);
        
	//Indicamos su dise�o
		contentPane.setLayout(null);
		//contentPane.setLayout(new BorderLayout(0, 0));
		
	//asigno el pannel a la ventana
		setContentPane(contentPane);
		
	//??	
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
	//Vamos a crear una etiqueta:	
		JLabel etiqueta=new JLabel("�Bienvenido a la DesktopApp!");
		//asignamos las medidas del campo
		etiqueta.setBounds(60, 20, 200, 20);
		contentPane.add(etiqueta);
	
	//vamos a agregar un campo de texto:
		JTextField textField = new JTextField();
		textField.setBounds(43, 67, 200, 26);
		contentPane.add(textField);
		
	//Vamos a agregar un bot�n:
		JButton btnPulsame = new JButton("Ejecutar");
		btnPulsame.setBounds(43, 133, 89, 23);
		contentPane.add(btnPulsame);
		
		
	//Vamos a agregar un bot�n de radio:
		JRadioButton rdbtnOpcion= new JRadioButton("Opcion 1", true);
        rdbtnOpcion.setBounds(43, 194, 109, 23);
        contentPane.add(rdbtnOpcion);

        JRadioButton rdbtnOpcion_1 = new JRadioButton("Opcion 2", false);
        rdbtnOpcion_1.setBounds(43, 220, 109, 23);
        contentPane.add(rdbtnOpcion_1);

        JRadioButton rdbtnOpcion_2 = new JRadioButton("Opcion 3", false);
        rdbtnOpcion_2.setBounds(43, 246, 109, 23);
        contentPane.add(rdbtnOpcion_2);

        ButtonGroup bgroup = new ButtonGroup();
        bgroup.add(rdbtnOpcion);
        bgroup.add(rdbtnOpcion_1);
        bgroup.add(rdbtnOpcion_2);
		
	//vamos a crear un bot�n con checkbox
        JCheckBox chckbxOpcion = new JCheckBox("Opcion1", true);
        chckbxOpcion.setBounds(43, 305, 97, 23);
        contentPane.add(chckbxOpcion);
         
        JCheckBox chckbxNewCheckBox = new JCheckBox("Opcion 2", true);
        chckbxNewCheckBox.setBounds(43, 325, 97, 23);
        contentPane.add(chckbxNewCheckBox);
         
        JCheckBox chckbxOpcion_1 = new JCheckBox("Opcion3", false);
        chckbxOpcion_1.setBounds(43, 346, 97, 23);
        contentPane.add(chckbxOpcion_1);
        
    //vamos a agregar un campo con texto de area
        JTextArea textArea = new JTextArea("Esto es un texto simple en una caja de texto con area"
        		+ "Esto es un texto simple en una caja de texto con area"
        		+ "Esto es un texto simple en una caja de texto con area"
        		+ "Esto es un texto simple en una caja de texto con area"
        		+ "Esto es un texto simple en una caja de texto con area"
        		+ "Esto es un texto simple en una caja de texto con area");
        textArea.setBounds(250, 18, 141, 117);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        contentPane.add(textArea);
        //a�adimos un scroll para poder visualizar el texto entero:
        	JScrollPane scroll = new JScrollPane(textArea); //Objeto
        	scroll.setBounds(250, 18, 141, 117); //Misma coordenadas y tama�o que el objeto
        	contentPane.add(scroll);
        
    //vamos a agregar un campo para contrase�as
        	JPasswordField pwd = new JPasswordField("Lutencio");
        	pwd.setBounds(189, 171, 139, 20);
        	contentPane.add(pwd);
        	
	//vamos a agregar un campo de seleccion
        	JComboBox<Object> comboBox = new JComboBox<>();
        	comboBox.setBounds(189, 221, 141, 22);
        	contentPane.add(comboBox);
        		comboBox.addItem("Fernando");
        		comboBox.addItem("Alberto");
        		comboBox.addItem("Arturo");
	
	//vamos a agregar un interruptor
        	JToggleButton tglbtnNewToggleButton = new JToggleButton("Interruptor", true);
        	tglbtnNewToggleButton.setBounds(189, 291, 121, 23);
       		contentPane.add(tglbtnNewToggleButton);	
    
	//agregamos un JSpinner
       		JSpinner spinner = new JSpinner();
       		spinner.setBounds(400, 20, 29, 20);
       		contentPane.add(spinner);
    
	//agregamos un Arrays de String
       		String pelis[]={"Star wars: la venganza de los siths", "El se�or de los anillos: el retorno del rey", "Guerra mundial Z", "Revolution", "007: Todo o Nada"};
       		JList<String> list = new JList<>(pelis);
       		list.setBounds(400, 72, 150, 80);
       		contentPane.add(list);	
       	//Scroll asociado a la lista
            JScrollPane scroll2 = new JScrollPane(list); //Objeto
            scroll2.setBounds(400, 72, 150, 80); //Misma coordenadas y tama�o que el objeto
            contentPane.add(scroll2);
       		
       		
		
	}
	
	
}
