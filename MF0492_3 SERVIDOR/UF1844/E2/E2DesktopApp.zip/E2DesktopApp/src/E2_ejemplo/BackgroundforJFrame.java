package E2_ejemplo;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
class BackgroundforJFrame extends JFrame
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton b1;
    JLabel l1;

    public BackgroundforJFrame()
    {
        setTitle("Background Color for JFrame");
        setSize(400,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

       
        
        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("C:\\eclipse\\eclipse\\eclipse-workspace\\images\\luffy.jpg")));
        setLayout(new FlowLayout());
       // l1=new JLabel("Here is a button");
       // b1=new JButton("I am a button");
       // add(l1);
       // add(b1);
        // Just for refresh :) Not optional!
       setSize(399,399);
       setSize(400,400);
    }

    public static void main(String args[])
    {
        new BackgroundforJFrame();
    }
} 