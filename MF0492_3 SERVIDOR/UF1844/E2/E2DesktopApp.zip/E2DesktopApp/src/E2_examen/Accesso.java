package E2_examen;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Color;

public class Accesso extends JFrame {

	/**
	 * Pretendo utilizar el codigo para crear una ventana en la que introducir credenciales, una vez dentro
	 * poder seleccionar que texto o cosa ver
	 * y lpor ultimo mostrar en otra ventana el contenido seleccionado
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Accesso frame = new Accesso();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**Creamos la funcion para la ventana de acceso*/
	
	public Accesso() {
		//A�ade un titulo, no es estrictamente necesario
			setTitle("DesktopApp");        
		/*Indica que cuando se cierre la ventana se acaba la aplicacion, 
		* si no lo indicamos cuando cerremos la ventana la aplicacion seguira funcionando*/
			setDefaultCloseOperation(EXIT_ON_CLOSE);		
		/*Coordenadas x y de la aplicacion y su altura y longitud,
		 * si no lo indicamos aparecera una ventana muy peque�a...
		 * 1� valor desde el margen,  
    	 * 2� valor altura, 
    	 * 3�longitud del campo, y 
    	 * 4� anchura del campo*/
			setBounds(250, 250, 300, 150);		
		//Creamos el panel asignando a una variable (contentPane) la funci�n que crea la ventana
			contentPane = new JPanel();		
			contentPane.setBackground(new Color(221, 160, 221));
		//Hace visible la ventana, si no lo hacemos no veremos la aplicacion
			setVisible(true);        
		//Indicamos su dise�o
			contentPane.setLayout(null);		
		//asigno el pannel a la ventana
			setContentPane(contentPane);
			
		
//Ventana para verificar 
            
        //Vamos a crear una etiqueta para el nombre:	
				JLabel et_nombre=new JLabel("Username:");
				//asignamos las medidas del campo
    				et_nombre.setBounds(15, 15, 100, 20);
    				contentPane.add(et_nombre);
           
    	//Agregar un campo de texto:
    			JTextField textField = new JTextField();
    			textField.setBackground(new Color(248, 248, 255));
    			textField.setBounds(15, 40, 100, 20); 
    			contentPane.add(textField);
    	
    	//Etiqueta para la contrase�a:	
				JLabel et_pass=new JLabel("Password:");
				//asignamos las medidas del campo
				et_pass.setBounds(170, 15, 100, 20);
    				contentPane.add(et_pass);
    				
    	//Agregar campo para contrase�a:
        	JPasswordField passField = new JPasswordField("");
        	passField.setBackground(new Color(248, 248, 255));
        	passField.setBounds(170, 40, 100, 20);
        	contentPane.add(passField);
        
       //Agregamos bot�n:
        	JButton btnacc = new JButton("Sing in");
        	btnacc.setBackground(new Color(211, 211, 211));
        	//Codigo para comprobar usuario y contrase�a.
        	btnacc.addActionListener(new ActionListener(){
        		public void actionPerformed(ActionEvent arg0){
        			//creamos variables para los campos:
                		String nombre = textField.getText(); //llamamos a la variable que actua como campo de texto para el nombre (textField)
                		char pass_content[] = passField.getPassword();
                		String password = new String(pass_content);
                		if (nombre.equals("admin") && password.equals("1234")) {
                			setVisible(false); //escondemos la ventana de acceso
                			Formulario nm = new Formulario(); //llama al JFrame llamado Formulario......
                		}
                		else {
                			JOptionPane.showMessageDialog(null, "Usuario o contrase�a incorrecto");
                		}			
        		}
        	});
        	btnacc.setBounds(90, 75, 100, 20);
        	contentPane.add(btnacc);
            
//Ventana con seleccion
            
//Ventana con contenido
            
            
	}
}
