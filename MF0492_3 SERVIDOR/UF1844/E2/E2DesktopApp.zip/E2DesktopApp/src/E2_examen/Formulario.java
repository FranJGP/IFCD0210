package E2_examen;

import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.SystemColor;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Formulario extends JFrame {

	/** Este codigo representa al formulario*/
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Formulario frame = new Formulario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Formulario() {
		//A�ade un titulo, no es estrictamente necesario
		setTitle("One Piece Personajes");        
	/*Indica que cuando se cierre la ventana se acaba la aplicacion, 
	* si no lo indicamos cuando cerremos la ventana la aplicacion seguira funcionando*/
		setDefaultCloseOperation(EXIT_ON_CLOSE);		
	/*Coordenadas x y de la aplicacion y su altura y longitud,
	 * si no lo indicamos aparecera una ventana muy peque�a...
	 * 1� valor desde el margen,  
	 * 2� valor altura, 
	 * 3�longitud del campo, y 
	 * 4� anchura del campo*/
		setBounds(250, 250, 420, 150);		
	//Creamos el panel asignando a una variable (contentPane) la funci�n que crea la ventana
		contentPane = new JPanel();		
		contentPane.setBackground(new Color(221, 160, 221));
	//Hace visible la ventana, si no lo hacemos no veremos la aplicacion
		setVisible(true);        
	//Indicamos su dise�o
		contentPane.setLayout(null);		
	//asigno el pannel a la ventana
		setContentPane(contentPane);
		
		//campo de seleccion
    	JComboBox<Object> comboBox = new JComboBox<>();
    	comboBox.setBackground(SystemColor.inactiveCaption);
    	comboBox.setBounds(21, 21, 141, 22);
		contentPane.add(comboBox);
    		comboBox.addItem("Luffy");
    		comboBox.addItem("Zoro");
    		comboBox.addItem("Nami");/*
    		comboBox.addItem("Sanji");
    		comboBox.addItem("Chopper");
    		comboBox.addItem("Franky");
    		comboBox.addItem("Usoop");
    		comboBox.addItem("Robin");
    		comboBox.addItem("Brook");*/
    		
    		JButton btnNewButton = new JButton("Ver");
    		btnNewButton.addActionListener(new ActionListener() {
    			public void actionPerformed(ActionEvent arg0) {
    				String contenido =  (String) comboBox.getSelectedItem();
    				if (contenido.equals("Luffy")) {
    					Luffy nw = new Luffy();
    	    		}
    				else if (contenido.equals("Nami")) {
    					Nami nw = new Nami();
    	    		}
    				else if (contenido.equals("Zoro")) {
    					Zoro nw = new Zoro();
    	    		}
    				
    			}
    		});
    		btnNewButton.setBounds(185, 21, 89, 23);
    		contentPane.add(btnNewButton);
		
    		JButton btnNewButton2 = new JButton("Atr�s");
    		btnNewButton2.addActionListener(new ActionListener() {
    			public void actionPerformed(ActionEvent arg0) {
    				Formulario nm =new Formulario();
    			}
    		});
    		btnNewButton2.setBounds(298, 21, 89, 23);
    		contentPane.add(btnNewButton2);
    		
    		
    	
    		
    		
    		
    		
    		
	}
}
