<script type="text/javascript">
    setInterval(function(){
        window.location.href="../index.php";
    },2000)
</script>
<?php

    $id=$_REQUEST['id']; /*variable recibe [] aqui dentro el NAME del echo de modificar_form.php*/
    $name=$_REQUEST['name'];
    $continent=$_REQUEST['continent'];
    $profits=$_REQUEST['profits'];
    $priority=$_REQUEST['priority'];

    include("../conectar.php");
    include ("../estilo.php");

    $consulta="UPDATE destinations SET id='$id', name='$name', continent='$continent', profits='$profits', priority='$priority' WHERE id='$id'";

    $sql=mysqli_query($conexion,$consulta);
    if($sql){
        echo "<p class= 'mensaje exito' > <h1>Modificado correctamente.</h1></p>";
    }
    else {
        echo "<p class= 'mensaje fracaso' > Error al insertar en la base de datos.</p>";
    }
    $conexion->close();
?>