<?php

    include("../conectar.php");
    include ("../estilo.php");

if(!empty($_GET["id"])){
    $consulta= "SELECT DISTINCT * FROM destinations WHERE id =" .$_GET["id"] .";";
    $result = mysqli_query($conexion, $consulta) or  die ("Falla la consulta a modificar");
    $obj = mysqli_fetch_array($result);
    $id=$obj['id'];
    $name=$obj['name'];
    $continent=$obj['continent'];
    $profits=$obj['profits'];
    $priority=$obj['priority'];
}

    echo "<center>";
    echo "<form method='get' action='modificar_con.php'>";
    echo "<h1>Formulario de modificacion</h1><br>";
    echo "ID:<br>";
    echo "<input type='text' name='id' value=".$id." readonly><br>";
    echo "Nombre:<br>";
    echo "<input type='text' name='name' value=".$name."><br>";
    echo "Continente:<br>";
    echo "<input type='text' name='continent' value=".$continent."><br>";
    echo "Profits:<br>";
    echo "<input type='text' name='profits' value=".$profits."><br>";
    echo "Priority:<br>";
    echo "<input type='text' name='priority' value=".$priority."><br>";
    echo "<br>";
    echo "<br>";
    echo "<input type='submit' value='MODIFICAR'>";
    echo "<br>";
    echo "<br>";
    echo "<center><button type='submit'><a href='../index.php'>ATRÁS</a></button></center>";
    echo "</form>";

    echo "</center>";

?>