<?php
    $id=$_REQUEST['id'];
    $name=$_REQUEST['name'];
    $continent=$_REQUEST['continent'];
    $profits=$_REQUEST['profits'];
    $priority=$_REQUEST['priority'];

    include("../conectar.php");
    include ("../estilo.php");

    $consulta="INSERT INTO `destinations` (`id`,`name`,`continent`,`profits`,`priority`) VALUES ('$id','$name','$continent','$profits','$priority')";
    $sql=mysqli_query($conexion,$consulta);
    if($sql){
        echo "<p class= 'mensaje exito' > <h1>Insertado correctamente.</h1></p>";
        echo "<button type='submit'>
            <a href='../index.php'>Volver al indice</a>
        </button><br>";
        echo "<button type='submit'>
            <a href='../mostrar/mostrar_form.php'>Mostrar resultado</a>
        </button><br>";
        echo "<button type='submit'>
            <a href='alta_form.php'>Nueva alta</a>
        </button><br>";
    }
    else {
        echo "<p class= 'mensaje fracaso' > Erros al insertar en la base de datos.</p>";
    }
    $conexion->close();
?>