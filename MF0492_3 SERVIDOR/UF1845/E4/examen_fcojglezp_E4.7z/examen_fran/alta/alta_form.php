<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Formulario Alta</title>
</head>

<body>
    <?php
        include ("../estilo.php");
        echo "<center>";
        echo "<form method='get' action='insertar.php'>";
        echo "<h1>Formulario de registro</h1><br>";
         echo "<br>";
        echo "ID:<br>";
        echo "<input type='text' name='id'><br>";
        echo "Nombre:<br>";
        echo "<input type='text' name='name'><br>";
        echo "Continente:<br>";
        echo "<input type='text' name='continent'><br>";
        echo "Profits:<br>";
        echo "<input type='text' name='profits'><br>";
        echo "Priority:<br>";
        echo "<input type='text' name='priority'><br>";
        echo "<br>";
        echo "<input type='submit' value='DAR DE ALTA'>";
        echo "</form>";
        echo "</center>";
    ?>
    <br>
    <br>
    <center><button type="submit"><a href="../index.php">ATRÁS</a></button></center>
    <br>
</body>
</html>