<!--Script para que pasado un tiempo, vuelva -->
<script type="text/javascript">
    setInterval(function(){
        window.location.href="../index.php";
    },2000)
</script>
<?php
    $id=$_REQUEST['id'];
    $name=$_REQUEST['name'];
    $continent=$_REQUEST['continent'];
    $profits=$_REQUEST['profits'];
    $priority=$_REQUEST['priority'];

    include("../conectar.php");
    include ("../estilo.php");

    $consulta="SELECT * FROM destinations WHERE id='$id', name='$name', continent='$continent', profits='$profits', priority='$priority'"; 
    $resultado=mysqli_query( $conexion, $consulta );
        echo "<div id='contenedor'>";
        echo "<center>";
        echo "<table border='1'>";
        echo "<tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Continente</th>
                <th>Profits</th>
                <th>Priority</th>
                <th>Modificar</th></tr>";
        /* Mostrar el objeto */
        while ($obj = mysqli_fetch_object($resultado)) {
            // Mostrar registro
            echo "<tr>";
            echo "<td>".$obj->id."</td>";
            echo "<td>".$obj->name."</td>";
            echo "<td>".$obj->continent."</td>";
            echo "<td>".$obj->profits."</td>";
            echo "<td>".$obj->priority."</td>";
           
            echo "<td><a href=modificar_form.php?id=".$obj->id."&name=".$obj->name."&continent=".$obj->continent."&profits=".$obj->profits."&priority=".$obj->priority.">MODIFICAR</a></td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "</center>";
        echo "<div>";
        echo "<br>";
        echo "<br>";
    
    $conexion->close();
?>