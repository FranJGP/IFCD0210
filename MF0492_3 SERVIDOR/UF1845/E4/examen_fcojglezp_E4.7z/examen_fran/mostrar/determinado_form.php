<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Formulario mostrar</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>

<body>
    <?php

    $id;
    $name;
    $continent;
    $profits;
    $priority;

        include("../conectar.php");
        include ("../estilo.php");


    echo "<center>";
    echo "<form method='get' action='determinado.php'>";
    echo "<h1>Formulario de modificacion</h1><br>";
    echo "ID:<br>";
    echo "<input type='text' name='id' value=".$id." readonly><br>";
    echo "Nombre:<br>";
    echo "<input type='text' name='name' value=".$name."><br>";
    echo "Continente:<br>";
    echo "<input type='text' name='continent' value=".$continent."><br>";
    echo "Profits:<br>";
    echo "<input type='text' name='profits' value=".$profits."><br>";
    echo "Priority:<br>";
    echo "<input type='text' name='priority' value=".$priority."><br>";
    echo "<br>";
    echo "<br>";
    echo "<input type='submit' value='MODIFICAR'>";
    echo "<br>";
    echo "<br>";
    echo "<center><button type='submit'><a href='../index.php'>ATRÁS</a></button></center>";
    echo "</form>";

    echo "</center>";;
    ?>
    
</body>
</html>