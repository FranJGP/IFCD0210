<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>index</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<?php include ("estilo.php");  ?>
	<div class="index">
		<div id="menu">
			<div class="bot">
				<a class="mostrar" href="mostrar/determinado_form.php"><span>MOSTRAR DETERMINADO.</span></a>
			</div>
			<div class="bot">
				<a class="mostrar" href="mostrar/mostrar_form.php"><span>MOSTRAR CLIENTES.</span></a>
			</div>
			<div class="bot">
				<a class="alta" href="alta/alta_form.php"><span>ALTA</span></a>
			</div>
			<div class="bot">
				<a class="modifi" href="modificar/general.php"><span>MODIFICAR</span></a>
			</div>
			<div class="bot">
				<a class="modifi" href="borrar/general.php"><span>BORRAR</span></a>
			</div>
			<div class="bot">
				<a class="modifi" href="imprimir/general.php"><span>IMPRIMIR</span></a>
			</div>
		</div>
	</div>
	<?php 
		include ("conectar.php");
		include ("estilo.php");
	 ?>
</body>
</html>