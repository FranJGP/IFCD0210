<!--Script para que pasado un tiempo, vuelva -->
<script type="text/javascript">
    setInterval(function(){
        window.location.href="../index.php";
    },2000)
</script>
<?php
    $id=$_REQUEST['id'];

    include("../conectar.php");

    $consulta="DELETE FROM destinations WHERE id=$id"; 
    $sql=mysqli_query($conexion,$consulta);
    if($sql){
        echo "<p class= 'mensaje exito' > <h1>Borrado correctamente.</h1></p>";
    }
    else {
        echo "<p class= 'mensaje fracaso' > Error al insertar en la base de datos.</p>";
    }
    $conexion->close();
?>