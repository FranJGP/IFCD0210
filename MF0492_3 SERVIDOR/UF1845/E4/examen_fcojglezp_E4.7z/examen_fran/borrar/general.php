<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>General</title>
    <link rel="stylesheet" href="../css/estilo.css">

<body>
    <?php
        include("../conectar.php");
        include ("../estilo.php");
        $conexion=mysqli_connect($host,$user,$pass,$db);

        /* Generamos la consulta */
        $consulta=" SELECT * FROM destinations ORDER BY id";
        $resultado=mysqli_query( $conexion, $consulta );
        echo "<div id='contenedor'>";
        echo "<center>";
        echo "<table border='1'>";
        echo "<tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Continente</th>
                <th>Profits</th>
                <th>Priority</th>
                <th>Borrar</th></tr>";
        /* Mostrar el objeto */
        while ($obj = mysqli_fetch_object($resultado)) {
            // Mostrar registro
            echo "<tr>";
            echo "<td>".$obj->id."</td>";
            echo "<td>".$obj->name."</td>";
            echo "<td>".$obj->continent."</td>";
            echo "<td>".$obj->profits."</td>";
             echo "<td>".$obj->priority."</td>";
            echo "<td><a href=borrar.php?id=".$obj->id.">BORRAR</a></td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "</center>";
        echo "<div>";
        echo "<br>";
        echo "<br>";
        $conexion->close();
    ?>
    <center><button type="submit"><a href="../index.php">ATRÁS</a></button></center>
    
</body>
</html>