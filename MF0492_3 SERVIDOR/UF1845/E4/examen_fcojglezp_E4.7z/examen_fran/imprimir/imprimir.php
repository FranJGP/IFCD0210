<script type="text/javascript">
    setInterval(function(){
        window.location.href="general.php";
    },2000)
</script>
<?php
/*  IMW - Generación de documentos en PDF  */
/* incluimos primeramente el archivo que contiene la clase fpdf */
include ('fpdf/fpdf.php');
/* tenemos que generar una instancia de la clase */
        $pdf = new FPDF();
        $pdf->AddPage();

/* seleccionamos el tipo, estilo y tamaño de la letra a utilizar */
        $pdf->SetFont('Arial', 'B', 18);
        // ENCABEZADO
                $pdf->Cell(120,10,"DATOS DESTINOS",0,1,'C');
                $pdf->SetFillColor(232,232,232);
                $pdf->SetFont('Arial', 'B', 15);
                $pdf->Ln();
                //$pdf->Cell();
                $pdf->Cell(38,7,"ID",1,0,'C');
                $pdf->Cell(38,7,"NOMBRE",1,0,'C');
                $pdf->Cell(38,7,"CONTINENTE",1,0,'C');
                $pdf->Cell(38,7,"PROFITS",1,0,'C');
                $pdf->Cell(38,7,"PRIORITY",1,0,'C');
                $pdf->Cell(38);

        // GENERAR REGISTRO
            // Incluimos datos de conexión.
                        include("../conectar.php");

            // COGEMOS IDALUMNO PARA IMPRIMIR INDIVIDUAL.
            $id = $_REQUEST["id"];

                        // Generamos la consulta.
                        $consulta = "select * from destinations where id=$id";
                        $sql = mysqli_query($conexion, $consulta);

                        // Miramos cuántos registros van a salir.
                        $numfilas = mysqli_num_rows($sql);

                        // GENERAR LAS CELDAS DE REGISTROS
                        
                                for ($i=0; $i < $numfilas; $i++) { 
                                        $registro = mysqli_fetch_array($sql);
                                $pdf->Ln(7);
                                //$pdf->Cell();
                                $pdf->Cell(38,7,$registro['id'],1,0,'C');
                                $pdf->Cell(38,7,$registro['name'],1,0,'C');
                                $pdf->Cell(38,7,$registro['continent'],1,0,'C');
                                $pdf->Cell(38,7,$registro['profits'],1,0,'C');
                                $pdf->Cell(38,7,$registro['priority'],1,0,'C');
                                $pdf->Cell(38);
                    }

        $pdf->Output("prueba.pdf",'F');
                echo "<script language='javascript'>window.open('prueba.pdf','_self','');</script>";
                //para ver el archivo pdf generado
                exit;
        ?>