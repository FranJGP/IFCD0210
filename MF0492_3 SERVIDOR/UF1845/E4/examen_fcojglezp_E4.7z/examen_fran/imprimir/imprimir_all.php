
<?php
require ('fpdf/fpdf.php');
require ('../conectar.php');
class PDF extends FPDF {
	function header() {
		$this->SetFont('Arial','B',15);
		$this->Cell(30);
		$this->Cell(120,10,'DATOS DE TODOS LOS DESTINOS',0,0,'C');
		$this->Ln(20);
	}
}

$query = "SELECT * FROM destinations";
$resultado = $conexion->query($query);
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->Addpage();

$pdf->SetFillColor(232,232,232);
$pdf->SetFont('Arial','B',15);
$pdf->Cell(38,6,'ID',1,0,'C',1);
$pdf->Cell(38,6,'NOMBRE',1,0,'C',1);
$pdf->Cell(38,6,'CONTINENTE',1,0,'C',1);
$pdf->Cell(38,6,'PROFITS',1,0,'C',1);
$pdf->Cell(38,6,'PRIORITY',1,1,'C',1);

$pdf->SetFont('Arial','',10);

while($row = $resultado->fetch_assoc())
{
    $pdf->Cell(38,6,$row['id'],1,0,'C',1);
    $pdf->Cell(38,6,$row['name'],1,0,'C',1);
    $pdf->Cell(38,6,$row['continent'],1,0,'C',1);
    $pdf->Cell(38,6,$row['profits'],1,0,'C',1);
    $pdf->Cell(38,6,$row['priority'],1,1,'C',1);
}

$pdf->Output();