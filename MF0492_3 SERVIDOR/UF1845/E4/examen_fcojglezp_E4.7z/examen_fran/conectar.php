<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "db_fran"; /*Nombre de la base de datos con la que se quiera conectar.*/
    $conexion = mysqli_connect($host, $user, $pass, $db) or die(mysql_error()); 
    	/*La variable $conexion ejecuta la funcion - mysql_connect - y en caso de no conectar, ejecuta - mysql_error -*/
    mysqli_set_charset($conexion, "utf8"); 
    	/*paara que pille las tildes y demás caracteres propios de nuestro lenguaje*/
?>