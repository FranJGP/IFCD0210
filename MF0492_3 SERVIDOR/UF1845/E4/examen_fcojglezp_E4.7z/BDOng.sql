-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generaci�n: 15-06-2011 a las 16:18:03
-- Versi�n del servidor: 5.1.49
-- Versi�n de PHP: 5.3.3-1ubuntu9.5
CREATE DATABASE db_fran;
USE db_fran;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sosplanet`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `iddestination` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `maxnumvolunteers` int(6) NOT NULL,
  `minnumvolunteers` int(6) NOT NULL,
  `subscribevolunteers` int(6) NOT NULL,
  `organization` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `iddestination` (`iddestination`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `activities`
--

INSERT INTO `activities` (`id`, `type`, `name`, `description`, `iddestination`, `maxnumvolunteers`, `minnumvolunteers`, `subscribevolunteers`, `organization`) VALUES
('', 'Tareas de soporte', 'Instalacion de hospitales de campa�a', 'Instalaci�n y soporte para el establecimiento de hospitales de campa�a en zonas de conflicto militar.', '4', 20, 8, 11, 'Cruz Roja'),
('20001', 'Recogida petroleo', 'Costas plagadas de crudo', 'Ven a limpiar las costas del destino seleccionado. Las tareas son recoger el crudo de las piedras e intentar salvar los animales.', '8', 30, 10, 0, 'Greenpeace'),
('20002', 'Terremoto', 'Ayuda a las victimas del terremoto', 'Entre todos, podemos echar una mano a todas esas victimas del terremoto de japon. ', '1', 40, 20, 0, 'Intermon Oxfam'),
('20003', 'Misionero', 'Haz de misionero en el Congo', 'Necesitamos un buen numero de misioneros en el Congo para labores de ense�anza y cuidados medicos.', '2', 55, 12, 0, 'Unicef'),
('20004', 'Profesorado', 'Puestos de profesorado', 'Si hay alguien interesado en viajar y ense�ar, esta es tu actividad.', '6', 20, 0, 0, 'Intermon Oxfam'),
('20005', 'Misionero', 'Misioneros en Kenya', 'Se precisan misioneros para ayudas humanitarias en Kenya.', '3', 60, 20, 0, 'Unicef');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `nick` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`nick`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `admin`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `category` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `categories`
--

INSERT INTO `categories` (`category`) VALUES
('Coleccionismo'),
('Deportes'),
('Electronica'),
('Herramientas'),
('Informatica'),
('Juguetes'),
('Libros'),
('Otros'),
('Ropa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `option` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `option` (`option`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=242 ;

--
-- Volcar la base de datos para la tabla `countries`
--

INSERT INTO `countries` (`id`, `option`) VALUES
(1, 'Afganistán'),
(2, 'Albania'),
(3, 'Alemania'),
(4, 'American Samoa'),
(5, 'Andorra'),
(6, 'Angola'),
(7, 'Anguila'),
(10, 'Antártida'),
(8, 'Antigua y Barbuda'),
(9, 'Antillas Holandesas'),
(11, 'Arabia Saudí'),
(12, 'Argelia'),
(13, 'Argentina'),
(14, 'Armenia'),
(15, 'Aruba'),
(17, 'Australia'),
(18, 'Austria'),
(19, 'Azerbaijan'),
(39, 'Bélgica'),
(20, 'Bahamas'),
(21, 'Bahrein'),
(22, 'Bangladesh'),
(23, 'Barbados'),
(24, 'Belice'),
(25, 'Benin'),
(26, 'Bermuda'),
(27, 'Bielorrusia'),
(28, 'Bolivia'),
(29, 'Bosnia y Herzegovina'),
(30, 'Botsuana'),
(31, 'Bouvet Island'),
(32, 'Brasil'),
(33, 'British Indian Ocean Terr.'),
(34, 'Brunei Darussalam'),
(35, 'Bulgaria'),
(36, 'Burkina Faso'),
(37, 'Burundi'),
(38, 'Bután'),
(40, 'Cabo Verde'),
(41, 'Camboya'),
(42, 'Camerún'),
(44, 'Canadá'),
(45, 'Chad'),
(46, 'Chile'),
(47, 'China'),
(48, 'Chipre'),
(49, 'Colombia'),
(50, 'Comores'),
(51, 'Congo'),
(52, 'Corea del Norte'),
(53, 'Corea del Sur'),
(54, 'Costa de Marfil'),
(55, 'Costa Rica'),
(56, 'Croacia'),
(57, 'Cuba'),
(58, 'Dinamarca'),
(59, 'Djibouti'),
(60, 'Dominica'),
(61, 'East Timor'),
(62, 'Ecuador'),
(63, 'Egipto'),
(64, 'El Salvador'),
(65, 'El Vaticano'),
(66, 'Emiratos Árabes Unidos'),
(67, 'Eritrea'),
(68, 'Eslovaquia'),
(69, 'Eslovenia'),
(70, 'España'),
(71, 'Estados Unidos'),
(72, 'Estonia'),
(73, 'Etiopía'),
(74, 'Fiji'),
(75, 'Filipinas'),
(76, 'Finlandia'),
(77, 'Francia'),
(78, 'French Guiana'),
(79, 'French Polynesia'),
(80, 'French Southern Terr.'),
(81, 'Gabón'),
(82, 'Gambia'),
(83, 'Georgia'),
(84, 'Ghana'),
(85, 'Gibraltar'),
(86, 'Granada'),
(87, 'Grecia'),
(88, 'Groenlandia'),
(89, 'Guadalupe'),
(90, 'Guam'),
(91, 'Guatemala'),
(92, 'Guinea'),
(93, 'Guinea Ecuatorial'),
(94, 'Guinea-Bissau'),
(95, 'Guyana'),
(96, 'Haití'),
(97, 'Heard and McDonald Islands'),
(98, 'Holanda'),
(99, 'Honduras'),
(100, 'Hong Kong'),
(101, 'Hungría'),
(102, 'India'),
(103, 'Indonesia'),
(104, 'Iraq'),
(105, 'Irlanda'),
(107, 'Isla Christmas'),
(108, 'Islandia'),
(109, 'Islas Caimán'),
(106, 'Islas Cocos'),
(110, 'Islas Cook'),
(111, 'Islas Feroe'),
(112, 'Islas Malvinas'),
(113, 'Islas Marshall'),
(114, 'Islas Mauricio'),
(115, 'Islas Salomón'),
(116, 'Islas Sandwhich'),
(117, 'Islas Turks y Caicos'),
(118, 'Islas Wallis y Futuna'),
(119, 'Israel'),
(120, 'Italia'),
(121, 'Jamaica'),
(122, 'Japón'),
(123, 'Jordania'),
(124, 'Kazajistán'),
(125, 'Kenia'),
(126, 'Kiribati'),
(127, 'Kuwait'),
(128, 'Kyrguizistán'),
(137, 'Líbano'),
(129, 'Laos'),
(130, 'Lesoto'),
(131, 'Letonia'),
(132, 'Liberia'),
(133, 'Libia'),
(134, 'Liechtenstein'),
(135, 'Lituania'),
(136, 'Luxemburgo'),
(156, 'México'),
(157, 'Mónaco'),
(138, 'Macao'),
(139, 'Macedonia'),
(140, 'Madagascar'),
(145, 'Malí'),
(141, 'Malasia'),
(142, 'Malaui'),
(143, 'Maldivas'),
(144, 'Malta'),
(146, 'Marruecos'),
(147, 'Martinique'),
(148, 'Mauritania'),
(149, 'Mayotte'),
(150, 'Micronesia'),
(151, 'Moldavia'),
(152, 'Mongolia'),
(153, 'Montserrat'),
(154, 'Mozambique'),
(155, 'Myanmar'),
(169, 'Níger'),
(158, 'Namibia'),
(159, 'Nauru'),
(160, 'Nepal'),
(161, 'Nicaragua'),
(162, 'Nigeria'),
(163, 'Niue'),
(164, 'Norfolk Island'),
(165, 'Northern Mariana Islands'),
(166, 'Noruega'),
(167, 'Nueva Caledonia'),
(168, 'Nueva Zelanda'),
(170, 'Omán'),
(171, 'Pakistán'),
(172, 'Palau'),
(173, 'Palestinian Territory'),
(174, 'Panamá'),
(175, 'Papúa Nueva Guinea'),
(176, 'Paraguay'),
(177, 'Perú'),
(178, 'Pitcairn'),
(179, 'Polonia'),
(180, 'Portugal'),
(181, 'Puerto Rico'),
(182, 'Qatar'),
(183, 'Reino Unido'),
(184, 'República Centroafricana'),
(185, 'República Checa'),
(186, 'República Dem. del Congo'),
(187, 'República Dominicana'),
(188, 'República Islámica de Irán'),
(189, 'Ruanda'),
(190, 'Rumanía'),
(191, 'Rusia'),
(192, 'Saint Kitts and Nevis'),
(193, 'Saint Pierre y Miquelon'),
(194, 'Samoa'),
(195, 'San Marino'),
(196, 'San Vicente y Las Granadinas'),
(197, 'Santa Elena'),
(198, 'Santa Lucía'),
(199, 'Sao Tome and Principe'),
(200, 'Senegal'),
(201, 'Serbia y Montenegro'),
(202, 'Seychelles'),
(203, 'Sierra Leona'),
(204, 'Singapur'),
(205, 'Siria'),
(206, 'Somalía'),
(207, 'Sri Lanka'),
(208, 'Suazilandia'),
(209, 'Sudáfrica'),
(210, 'Sudán'),
(211, 'Suecia'),
(212, 'Suiza'),
(213, 'Surinam'),
(214, 'Svalbard and Jan Mayen'),
(215, 'Tailandia'),
(216, 'Taiwán'),
(217, 'Tajikistán'),
(218, 'Tanzania'),
(226, 'Túnez'),
(219, 'Togo'),
(220, 'Tonga'),
(221, 'Toquelau'),
(222, 'Trinidad y Tobago'),
(223, 'Turkmenistán'),
(224, 'Turquía'),
(225, 'Tuvalu'),
(227, 'Ucrania'),
(228, 'Uganda'),
(230, 'Uruguay'),
(229, 'US Minor Outlying Island'),
(231, 'Uzbekistan'),
(232, 'Vanuatu'),
(233, 'Venezuela'),
(234, 'Vietnam'),
(235, 'Virgin Islands British'),
(236, 'Virgin Islands U.S.'),
(237, 'Western Sahara'),
(238, 'Yemen'),
(239, 'Zaire'),
(240, 'Zambia'),
(241, 'Zimbabue');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `destinations`
--

CREATE TABLE IF NOT EXISTS `destinations` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `continent` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `profits` float NOT NULL DEFAULT '0',
  `priority` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `destinations`
--

INSERT INTO `destinations` (`id`, `name`, `continent`, `profits`, `priority`) VALUES
('', 'Peru', 'America del Sur', 2, 2),
('1', 'Japon', 'Asia', 0, 2),
('2', 'Congo', 'Africa', 0, 3),
('3', 'Kenya', 'Africa', 0, 3),
('4', 'Algeria', 'Africa', 0, 1),
('5', 'Madagascar', 'Africa', 0, 9),
('6', 'Venezuela', 'America del sur', 0, 4),
('7', 'Mexico', 'America del norte', 0, 2),
('8', 'Letonia', 'Europa', 0, 6),
('9', 'Tasmania', 'Australia', 0, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fieldattributes`
--

CREATE TABLE IF NOT EXISTS `fieldattributes` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `fieldattributes`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fieldvalues`
--

CREATE TABLE IF NOT EXISTS `fieldvalues` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `idfield` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idfield` (`idfield`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `fieldvalues`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mailbox`
--

CREATE TABLE IF NOT EXISTS `mailbox` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `idsender` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idreceiver` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `read` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsender` (`idsender`),
  KEY `idreceiver` (`idreceiver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `mailbox`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` float NOT NULL DEFAULT '0',
  `iddonor` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idbuyer` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iddestination` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sell` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `ratio` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `iddonor` (`iddonor`),
  KEY `idbuyer` (`idbuyer`),
  KEY `category` (`category`),
  KEY `iddestination` (`iddestination`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `category`, `name`, `description`, `price`, `iddonor`, `idbuyer`, `iddestination`, `regdate`, `sell`, `active`, `ratio`) VALUES
('9000', 'Libros', 'Harry Potter', 'El primer tomo de harry potter', 12, '5001', NULL, '5', '2011-06-13 14:40:09', 0, 1, 0.77),
('90000', 'Otros', 'Cenicero', 'Para echar la ceniza de los examenes quemaos.', 7.5, '5004', NULL, NULL, '2011-06-13 15:27:46', 0, 1, 0.5),
('9001', 'Ropa', 'Calzoncillo Ck', 'Calzoncillos calvin kipanga, talla M', 7.5, '5000', NULL, '8', '2011-06-13 14:41:54', 0, 1, 0.3),
('9002', 'Informatica', 'Ordenador toshiba', 'Lo vendo con poco uso. No tiene disco duro.', 45, '5003', NULL, '3', '2011-06-13 14:41:54', 0, 1, 0.6),
('9003', 'Herramientas', 'Pala', 'Una pala para cavar hoyos.', 12.5, '5004', NULL, '4', '2011-06-13 14:42:53', 0, 1, 0.75),
('9004', 'Ropa', 'Sudadera', 'Marca adidas, nueva a estrenar.', 45, '5010', NULL, '7', '2011-06-13 14:44:50', 0, 1, 0.56),
('9005', 'Electronica', 'Television de plasma', 'De 45 pulgadas. Teletexto incorporado.', 100, '5004', NULL, NULL, '2011-06-13 14:44:50', 0, 1, 0.86),
('9006', 'Herramientas', 'Martillo', 'Martillo seminuevo.', 5, '5000', NULL, NULL, '2011-06-13 14:46:28', 0, 1, 0.62),
('9007', 'Juguetes', 'Monopoly', 'Lo vendo por poco parecido con la realidad.', 33.5, '5004', NULL, '1', '2011-06-13 14:46:28', 0, 1, 0.99),
('9008', 'Informatica', 'Raton inalambrico', 'Un raton sin cables! Pilas no incluidas', 3.5, '5003', NULL, '6', '2011-06-13 14:50:50', 0, 1, 0.43),
('9009', 'Juguetes', 'Metal Gear: Twin Snakes', 'Lo vendo por falta de tiempo.Perfecto estado.', 77, '5001', NULL, NULL, '2011-06-13 14:50:50', 0, 1, 0.56),
('9010', 'Juguetes', 'Sillin de bici', 'Casi sin uso.', 70, '5001', NULL, NULL, '2011-06-13 14:52:27', 0, 1, 0.22),
('9011', 'Ropa', 'Gafas de listillo', 'Unas gafas que te hacen parecer inteligente', 35, '5004', NULL, NULL, '2011-06-13 14:52:27', 0, 1, 0.47),
('9012', 'Ropa', 'Camiseta betis', 'La camiseta de Joao Tomas', 80, '5003', NULL, NULL, '2011-06-13 14:55:26', 0, 1, 1.33),
('9013', 'Herramientas', 'Tornillo y tuerca', 'Perfecto estado.', 0.5, '5000', NULL, NULL, '2011-06-13 14:55:26', 0, 1, 0.83),
('9014', 'Coleccionismo', 'Moneda de un euro', 'Con la cara del rey', 1.5, '5010', NULL, '4', '2011-06-13 14:57:21', 0, 1, 0.28),
('9015', 'Otros', 'Cerebro', 'Lo vendo por falta de uso', 50, '5001', NULL, NULL, '2011-06-13 14:57:21', 0, 1, 0.41),
('9016', 'Libros', 'Pattern Dessign', 'Libro de patrones de dise�o visto en isg2', 35.99, '5003', NULL, '8', '2011-06-14 00:28:39', 0, 1, 0.8),
('9017', 'Otros', 'Tienda de campa�a', 'Ideal para acampar enfrente del ayuntamiento o en las setas cuando el pais entre en quiebra economica.', 19, '5006', NULL, '5', '2011-06-14 00:28:39', 0, 1, 0.9),
('9018', 'Coleccionismo', 'Copa del rey rota', 'Se le cayo a uno mientras celebraba el titulo.', 990, '5006', NULL, NULL, '2011-06-15 16:11:45', 0, 0, 0),
('9019', 'Coleccionismo', 'Cd de Camela', 'Un cd pirata del segundo disco de Camela', 30.5, '5001', NULL, '5', '2011-06-15 16:11:45', 0, 0, 0),
('9020', 'Deportes', 'Raqueta de f�tbol', 'Un bate de boxeo perfecto para quien se este iniciando en el mundo del motociclismo.', 33.3, '5006', NULL, NULL, '2011-06-15 16:15:28', 0, 0, 0),
('9021', 'Deportes', 'Canoa', 'Para dos personas. Remos incluidos', 90, '5000', NULL, '4', '2011-06-15 16:15:28', 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `purchasehistory`
--

CREATE TABLE IF NOT EXISTS `purchasehistory` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `totalproducts` int(3) NOT NULL,
  `totalprice` float NOT NULL,
  `date` date NOT NULL,
  `donorratio` float NOT NULL,
  `buyerratio` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `purchasehistory`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `requeriments`
--

CREATE TABLE IF NOT EXISTS `requeriments` (
  `requeriment` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`requeriment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `requeriments`
--

INSERT INTO `requeriments` (`requeriment`) VALUES
('Carnet conducir'),
('Experiencia en voluntariados'),
('First Ingles'),
('Mayoria edad'),
('Vacunado contra malaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `types`
--

INSERT INTO `types` (`type`) VALUES
('Misionero'),
('Plantacion'),
('Profesorado'),
('Recogida basura'),
('Recogida petroleo'),
('Tareas de soporte'),
('Terremoto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `userattributes`
--

CREATE TABLE IF NOT EXISTS `userattributes` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `values` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `iduser` (`iduser`),
  KEY `field` (`field`),
  KEY `values` (`values`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `userattributes`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `nick` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `mail` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `genre` tinyint(1) NOT NULL COMMENT 'True (1) = Male, False (0) = Female',
  `birthdate` date NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `country` int(3) DEFAULT NULL,
  `continent` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `postcode` int(5) NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `dni` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `isVolunteer` tinyint(1) NOT NULL DEFAULT '0',
  `isadmin` tinyint(1) NOT NULL,
  `donateratio` float NOT NULL DEFAULT '0',
  `purchaseratio` float NOT NULL DEFAULT '0',
  `volunteerratio` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick` (`nick`,`mail`),
  KEY `country` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `nick`, `mail`, `pass`, `genre`, `birthdate`, `regdate`, `name`, `surname`, `country`, `continent`, `city`, `postcode`, `address`, `dni`, `isVolunteer`, `isadmin`, `donateratio`, `purchaseratio`, `volunteerratio`) VALUES
('5000', 'tyson', 'tirso.rod@gmail.com', 'sosplanet', 1, '1987-05-07', '2011-06-13 14:30:38', 'Tirso', 'Rodriguez Velasco', 70, 'Europa', 'Sevilla', 41018, '', '28817672Y', 0, 1, 0, 0, 0),
('5001', 'Diepeltor', 'diegopelaez@gmail.com', 'sosplanet', 0, '0000-00-00', '2011-06-13 14:36:36', 'Diego', 'Pelaez Torres', 70, 'Europa', '', 41004, '', '', 0, 0, 0, 0, 0),
('5003', 'Franmorisco', 'fran@gmail.com', 'sosplanet', 1, '0000-00-00', '2011-06-13 14:37:52', 'Fran', 'Morisco', 70, 'Europa', 'La Puebla', 41020, '', '', 0, 0, 0, 0, 0),
('5004', 'minord', 'minord@gmail.com', 'sosplanet', 1, '0000-00-00', '2011-06-13 14:39:02', 'Fernando', 'Reina', 70, 'Europa', 'Sevilla', 41012, '', '', 0, 1, 0, 0, 0),
('5006', 'pafmon', 'pafmon@gmail.com', 'sosplanet', 1, '0000-00-00', '2011-06-13 14:58:34', 'Pablo', 'Fernandez', 70, 'Europa', 'Sevilla', 41001, '', '', 0, 0, 0, 0, 0),
('5010', 'pepe', 'pepe@gmail.com', 'sosplanet', 1, '1988-06-28', '2011-06-13 14:33:30', 'Pepe', '', 4, 'Africa', '', 41001, '', '', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `volunterrshistoy`
--

CREATE TABLE IF NOT EXISTS `volunterrshistoy` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iddestination` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idactivity` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `voting` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `iduser` (`iduser`),
  KEY `iddestination` (`iddestination`),
  KEY `idactivity` (`idactivity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `volunterrshistoy`
--


--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `activities_ibfk_1` FOREIGN KEY (`type`) REFERENCES `types` (`type`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `activities_ibfk_2` FOREIGN KEY (`iddestination`) REFERENCES `destinations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `fieldvalues`
--
ALTER TABLE `fieldvalues`
  ADD CONSTRAINT `fieldvalues_ibfk_1` FOREIGN KEY (`idfield`) REFERENCES `fieldattributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category`) REFERENCES `categories` (`category`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`iddonor`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_3` FOREIGN KEY (`idbuyer`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_4` FOREIGN KEY (`iddestination`) REFERENCES `destinations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `purchasehistory`
--
ALTER TABLE `purchasehistory`
  ADD CONSTRAINT `purchasehistory_ibfk_1` FOREIGN KEY (`iduser`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `userattributes`
--
ALTER TABLE `userattributes`
  ADD CONSTRAINT `userattributes_ibfk_1` FOREIGN KEY (`iduser`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userattributes_ibfk_2` FOREIGN KEY (`field`) REFERENCES `fieldattributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userattributes_ibfk_3` FOREIGN KEY (`values`) REFERENCES `fieldvalues` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`country`) REFERENCES `countries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `volunterrshistoy`
--
ALTER TABLE `volunterrshistoy`
  ADD CONSTRAINT `volunterrshistoy_ibfk_1` FOREIGN KEY (`iduser`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `volunterrshistoy_ibfk_2` FOREIGN KEY (`iddestination`) REFERENCES `destinations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `volunterrshistoy_ibfk_3` FOREIGN KEY (`idactivity`) REFERENCES `activities` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;